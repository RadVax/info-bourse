
function miseAJourCours() {
    // Simuler des cours aléatoires
    const coursOr = (1800 + Math.random() * 50).toFixed(2);
    const coursArgent = (25 + Math.random() * 2).toFixed(2);
    const eurUsd = (1.08 + Math.random() * 0.02).toFixed(4);
    const gbpUsd = (1.25 + Math.random() * 0.02).toFixed(4);
    const usdJpy = (110 + Math.random() * 2).toFixed(2);

    document.getElementById('cours-or').textContent = coursOr;
    document.getElementById('cours-argent').textContent = coursArgent;
    document.getElementById('cours-eurusd').textContent = eurUsd;
    document.getElementById('cours-gbpusd').textContent = gbpUsd;
    document.getElementById('cours-usdjpy').textContent = usdJpy;
}

// Mise à jour toutes les 10 secondes
miseAJourCours();
setInterval(miseAJourCours, 10000);
